ESX = nil
loaded = false

Citizen.CreateThread(function()
    while ESX == nil do
        ESX = exports["es_extended"]:getSharedObject()
        Citizen.Wait(1000)
        PlayerData = ESX.GetPlayerData()
    end
    loaded = true
end)


RegisterNetEvent("xdxd_peds:xdxd")
AddEventHandler("xdxd_peds:xdxd", function()
    TriggerEvent('chat:addMessage', {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(255, 0, 0, 0.6); border-radius: 3px;"><i class="fas fa-exclamation-triangle" style="font-size:20px;color:black"></i> <b><font color="black"> xd.xd:</font></b><br><b><font color="black">{1}</font></b></div>',
        args = {"xd.xd", "Köszönöm szépen hogy a scriptemet használod!"}
    })
end)


RegisterNetEvent("xdxd_peds:xdxd2")
AddEventHandler("xdxd_peds:xdxd2", function()
    TriggerEvent('chat:addMessage', {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(255, 0, 0, 0.6); border-radius: 3px;"><i class="fas fa-exclamation-triangle" style="font-size:20px;color:black"></i> <b><font color="black"> xd.xd:</font></b><br><b><font color="black">{1}</font></b></div>',
        args = {"xd.xd", "Legyél szerencsés egy életen át!"}
    })
end)
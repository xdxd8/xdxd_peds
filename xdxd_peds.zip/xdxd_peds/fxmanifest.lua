fx_version "badacious"

game { "gta5"}

author 'xdxd'
description 'Ped System'
version '1.0.0'

client_scripts {
    "client.lua",
    "config.lua",
    "messages.lua",
}

server_script{
    "config.lua",
}
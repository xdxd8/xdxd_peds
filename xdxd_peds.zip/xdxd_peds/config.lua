-- config.lua

Config = {
    {model = "s_m_m_mariachi_01", text = "~r~xd.xd", coords = vector3(-303.9621, -356.2361, 29.1631), heading = 180.0, scenario = "WORLD_HUMAN_AA_SMOKE", event = "xdxd_peds:xdxd"},
    {model = "s_m_m_mariachi_01", text = "~p~xd.xd", coords = vector3(-329.0512, -337.6711, 29.4197), heading = 180.0, scenario = "WORLD_HUMAN_AA_SMOKE", event = "xdxd_peds:xdxd2"},
}

ESX = nil
loaded = false

Citizen.CreateThread(function()
    while ESX == nil do
        ESX = exports["es_extended"]:getSharedObject()
        Citizen.Wait(1000)
        PlayerData = ESX.GetPlayerData()
    end
    loaded = true
end)

Citizen.CreateThread(function()
    while not loaded do
        Citizen.Wait(1000)
    end

    while true do
        Citizen.Wait(1000)

        for k, v in pairs(Config) do
            if not DoesEntityExist(v[1]) then
                RequestModel(v.model)
                while not HasModelLoaded(v.model) do
                    Citizen.Wait(1000)
                end

                v[1] = CreatePed(4, v.model, v.coords.x, v.coords.y, v.coords.z, v.heading, v.scenario)
                SetEntityAsMissionEntity(v[1])
                FreezeEntityPosition(v[1], true)
                SetBlockingOfNonTemporaryEvents(v[1], true)
                SetEntityInvincible(v[1], true)
                TaskStartScenarioInPlace(v[1], v.scenario)

                SetModelAsNoLongerNeeded(v.model)
            end

            local plyCoords = GetEntityCoords(PlayerPedId(), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, v.coords.x, v.coords.y, v.coords.z)

            if dist < 3 then
                v[7] = true
            else
                v[7] = false
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for k, v in ipairs(Config) do
            if v[7] then
                ESX.Game.Utils.DrawText3D({ x = v.coords.x, y = v.coords.y, z = v.coords.z + 2.0 }, v.text, 1.0)
                if IsControlJustPressed(0, 38) then
                    TriggerEvent(v.event)
                end
            end
        end
    end
end)

RegisterNetEvent("xdxd_peds:xdxd")
AddEventHandler("xdxd_peds:xdxd", function()
    TriggerEvent('chat:addMessage', {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(255, 0, 0, 0.6); border-radius: 3px;"><i class="fas fa-exclamation-triangle" style="font-size:20px;color:black"></i> <b><font color="black"> xd.xd:</font></b><br><b><font color="black">{1}</font></b></div>',
        args = {"xd.xd", "Köszönöm szépen hogy a scriptemet használod!"}
    })
end)


RegisterNetEvent("xdxd_peds:xdxd2")
AddEventHandler("xdxd_peds:xdxd2", function()
    TriggerEvent('chat:addMessage', {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(255, 0, 0, 0.6); border-radius: 3px;"><i class="fas fa-exclamation-triangle" style="font-size:20px;color:black"></i> <b><font color="black"> xd.xd:</font></b><br><b><font color="black">{1}</font></b></div>',
        args = {"xd.xd", "Legyél szerencsés egy életen át!"}
    })
end)
